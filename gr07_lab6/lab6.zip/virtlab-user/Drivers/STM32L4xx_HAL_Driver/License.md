License.md file kept for legacy purpose
