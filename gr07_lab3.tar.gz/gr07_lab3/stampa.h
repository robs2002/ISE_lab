#ifndef STAMPA_H
#define STAMPA_H

#define dimr 40  //320
#define dimc 30  //240

int stampaArea(int area[][dimc]);

#endif
