#ifndef SCANOFFILE_H
#define SCANODFILE_H

#define dimr 40
#define dimc 30

int scanfile(FILE *fp, int area[][dimc]);

#endif
