#ifndef ALGORITMO_H
#define ALGORITMO_H

#define dimr 40  //320
#define dimc 30  //240

int algoritmo_di_linea(int x1, int y1, int x2, int y2, int area[][dimc]);

#endif
