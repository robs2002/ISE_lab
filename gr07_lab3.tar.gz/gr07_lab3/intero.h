#ifndef INTERO_H
#define INTERO_H

int num_int(float t, int dim);

#endif
