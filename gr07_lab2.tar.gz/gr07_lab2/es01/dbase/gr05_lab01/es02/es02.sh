#!/bin/bash

echo "192.168.1.31 host1.polito.it host1
192.168.1.32 host2.polimi.it host2
192.168.1.33 host3.unito.it host3
192.168.1.34 host4.unimore.it host4
192.168.1.35 host5.tum.de host5
192.168.1.36 host6.tum.de host6">>hostRenamed.txt
