#!/bin/bash

echo "192.168.1.1 host1.polito.it host1
192.168.1.2 host2.polimi.it host2
192.168.1.3 host3.unito.it host3
192.168.1.4 host4.unimore.it host4
192.168.1.5 host5.tum.de host5
192.168.1.6 host6.tum.de host6">>hostRenamed.txt
